package com.zeljkosassets.notifications;

import java.util.Calendar;

import android.app.Activity;
import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import com.unity3d.player.UnityPlayer;
import com.unity3d.player.UnityPlayerNativeActivity;

public class Notifier extends BroadcastReceiver {

	//Unity calls this static method
	public static void sendNotification(String name, String title, String label, int secondsFromNow)
	{
		// Schedule the alarm!	
		Calendar c = Calendar.getInstance();
        c.add(Calendar.SECOND, secondsFromNow);
        Activity act = UnityPlayer.currentActivity;
        AlarmManager am = (AlarmManager)act.getSystemService(Context.ALARM_SERVICE);
        Intent ii = new Intent(act, Notifier.class);
        ii.putExtra("name", name);
        ii.putExtra("title", title);
        ii.putExtra("label", label);
        am.set(AlarmManager.RTC_WAKEUP, c.getTimeInMillis(), PendingIntent.getBroadcast(act, 0, ii, 0));
	}

	@Override
	public void onReceive(Context context, Intent intent) {
		// TODO Auto-generated method stub
		NotificationManager notificationManager = (NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);
        Notification notification = new Notification(R.drawable.ic_launcher, intent.getStringExtra("title"), System.currentTimeMillis());        
        Intent notificationIntent = new Intent(context, UnityPlayerNativeActivity.class); 
        notificationIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        PendingIntent Pintent = PendingIntent.getActivity(context, 0, notificationIntent, 0);
        notification.setLatestEventInfo(context, intent.getStringExtra("name"), intent.getStringExtra("label"), Pintent);
        notification.flags |= Notification.FLAG_AUTO_CANCEL;
        notification.defaults = Notification.DEFAULT_LIGHTS | Notification.DEFAULT_VIBRATE;
        notificationManager.notify(0, notification);
	}
	
}
